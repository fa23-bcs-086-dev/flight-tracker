from . import flights, search

# exposes: app.routes.flights, app.routes.search